#!/usr/bin/env python3
"""
07 — THE LAST WHISTLE
A cinematic tribute to MS Dhoni, built by Coding with Vishesh.

Run:  python dhoni_tribute.py
Python builds a self-contained cinematic page (procedural film score, embers,
stadium bokeh, letterbox, grain) and serves it on http://127.0.0.1:8007
Put your photo next to this file as dhoni.webp / dhoni.jpg / dhoni.png for the finale.
Keys: R replay | J jump to finale | M mute | F fullscreen
"""
import base64, glob, http.server, mimetypes, os, socketserver, threading, webbrowser

HERE = os.path.dirname(os.path.abspath(__file__))
SITE = os.path.join(HERE, "site")

HTML = r'''<!doctype html>
<html lang="hi"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>07 — The Last Whistle | Tribute to MS Dhoni</title>
<style>
html,body{margin:0;height:100%;background:#000;overflow:hidden;font-family:'Segoe UI','Noto Sans Devanagari',system-ui,sans-serif}
canvas{position:fixed;inset:0;width:100%;height:100%;display:block}
#ov{position:fixed;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;background:#000;color:#fff;z-index:5;text-align:center;gap:18px}
#ov h1{font-weight:200;letter-spacing:.5em;font-size:clamp(18px,3vw,34px);margin:0;color:#ffd43b}
#ov p{opacity:.6;margin:0;font-size:14px;letter-spacing:.1em}
#go{margin-top:12px;padding:16px 44px;border:1px solid #ffd43b;background:transparent;color:#ffd43b;font-size:16px;letter-spacing:.4em;cursor:pointer;transition:.3s}
#go:hover{background:#ffd43b;color:#000;box-shadow:0 0 50px #ffd43b88}
#hint{position:fixed;bottom:12px;right:16px;color:#fff6;font-size:12px;z-index:4;letter-spacing:.1em}
</style></head><body>
<canvas id="c"></canvas>
<div id="ov"><h1>07</h1><p>THE LAST WHISTLE &nbsp;·&nbsp; A TRIBUTE TO MS DHONI</p><p>Headphones lagao &nbsp;·&nbsp; fullscreen me dekho</p><button id="go">BEGIN</button></div>
<div id="hint">R replay · J finale · M mute · F fullscreen</div>
<script>__IMG__</script>
<script>
const $=id=>document.getElementById(id);
const C=$('c'),X=C.getContext('2d');let W,H;
function rs(){const d=Math.min(devicePixelRatio||1,2);W=innerWidth;H=innerHeight;C.width=W*d;C.height=H*d;X.setTransform(d,0,0,d,0,0)}
addEventListener('resize',rs);rs();
const clamp=(v,a=0,b=1)=>Math.min(b,Math.max(a,v));
const seg=(t,a,b,f=1)=>clamp((t-a)/f)*clamp((b-t)/f);
const ease=x=>x*x*(3-2*x);
const IMG=new Image();let imgOK=false;
if(window.DHONI_IMG){IMG.onload=()=>imgOK=true;IMG.onerror=()=>console.error('photo load failed');IMG.src=window.DHONI_IMG}

/* ---------- procedural film score ---------- */
let AC,master,crowdG,pads=[],muted=false;
function audioInit(){
 AC=new(window.AudioContext||window.webkitAudioContext)();
 const comp=AC.createDynamicsCompressor();master=AC.createGain();master.gain.value=.9;
 master.connect(comp);comp.connect(AC.destination);
 const now=AC.currentTime;
 [55,82.41,110,164.81,220].forEach(f=>[-7,7].forEach(d=>{
  const o=AC.createOscillator(),fl=AC.createBiquadFilter(),g=AC.createGain();
  o.type='sawtooth';o.frequency.value=f;o.detune.value=d;
  fl.type='lowpass';fl.frequency.value=300;
  g.gain.setValueAtTime(0,now);g.gain.linearRampToValueAtTime(.03,now+6);
  o.connect(fl);fl.connect(g);g.connect(master);o.start();pads.push({fl});
 }));
 const len=AC.sampleRate*2,b=AC.createBuffer(1,len,AC.sampleRate),d=b.getChannelData(0);
 for(let i=0;i<len;i++)d[i]=Math.random()*2-1;
 const ns=AC.createBufferSource();ns.buffer=b;ns.loop=true;
 const bp=AC.createBiquadFilter();bp.type='bandpass';bp.frequency.value=700;bp.Q.value=.6;
 crowdG=AC.createGain();crowdG.gain.value=0;
 ns.connect(bp);bp.connect(crowdG);crowdG.connect(master);ns.start();
}
function thump(v=1){const n=AC.currentTime,o=AC.createOscillator(),g=AC.createGain();
 o.frequency.setValueAtTime(110,n);o.frequency.exponentialRampToValueAtTime(38,n+.25);
 g.gain.setValueAtTime(.9*v,n);g.gain.exponentialRampToValueAtTime(.001,n+.35);
 o.connect(g);g.connect(master);o.start(n);o.stop(n+.4)}
function bell(f,at){const n=AC.currentTime+at;[1,2.01].forEach((m,i)=>{
 const o=AC.createOscillator(),g=AC.createGain();o.type=i?'triangle':'sine';o.frequency.value=f*m;
 g.gain.setValueAtTime(0,n);g.gain.linearRampToValueAtTime(.18/(i+1),n+.02);
 g.gain.exponentialRampToValueAtTime(.001,n+3.5);o.connect(g);g.connect(master);o.start(n);o.stop(n+3.6)})}
function crowd(v,s){const n=AC.currentTime;crowdG.gain.cancelScheduledValues(n);
 crowdG.gain.setValueAtTime(crowdG.gain.value,n);crowdG.gain.linearRampToValueAtTime(v,n+s)}
function bright(hz,s){const n=AC.currentTime;pads.forEach(p=>{p.fl.frequency.cancelScheduledValues(n);
 p.fl.frequency.setValueAtTime(p.fl.frequency.value,n);p.fl.frequency.linearRampToValueAtTime(hz,n+s)})}

/* ---------- visual layers ---------- */
const E=Array.from({length:180},()=>({x:Math.random(),y:Math.random(),s:Math.random()*2+.5,v:Math.random()*.04+.01,p:Math.random()*6.28}));
const B=Array.from({length:14},()=>({x:Math.random(),y:Math.random()*.6,r:Math.random()*90+50,p:Math.random()*6.28}));
function bg(t,w){
 const g=X.createLinearGradient(0,0,0,H);
 g.addColorStop(0,`rgb(${8+w*22},${10+w*16},${24+w*4})`);g.addColorStop(1,'#000');
 X.fillStyle=g;X.fillRect(0,0,W,H);
 X.globalCompositeOperation='lighter';
 B.forEach(b=>{const x=(b.x+Math.sin(t*.1+b.p)*.03)*W,y=(b.y+Math.cos(t*.12+b.p)*.02)*H,r=b.r*(W/1200+.4);
  const rg=X.createRadialGradient(x,y,0,x,y,r),a=.06+w*.12;
  rg.addColorStop(0,`rgba(255,200,40,${a})`);rg.addColorStop(1,'rgba(255,200,40,0)');
  X.fillStyle=rg;X.fillRect(x-r,y-r,r*2,r*2)});
 E.forEach(e=>{e.y-=e.v/60*(1+w*2);if(e.y<-.02){e.y=1.02;e.x=Math.random()}
  const a=(.3+.7*Math.abs(Math.sin(t*2+e.p)))*(.25+w*.75);
  X.fillStyle=`rgba(255,${170+Math.random()*50|0},40,${a})`;
  X.beginPath();X.arc(e.x*W+Math.sin(t+e.p)*12,e.y*H,e.s,0,6.28);X.fill()});
 X.globalCompositeOperation='source-over';
}
function T(s,x,y,sz,a,o={}){
 if(a<=.001)return;X.save();X.globalAlpha=a;X.fillStyle=o.c||'#fff';X.textAlign='center';X.textBaseline='middle';
 X.font=`${o.w||300} ${sz}px 'Segoe UI','Noto Sans Devanagari',system-ui,sans-serif`;
 if('letterSpacing' in X)X.letterSpacing=(o.ls||0)+'px';
 if(o.glow){X.shadowColor=o.glow;X.shadowBlur=o.gb||30}
 X.fillText(s,x,y);X.restore();
}
function post(t){
 const v=X.createRadialGradient(W/2,H/2,Math.min(W,H)*.25,W/2,H/2,Math.max(W,H)*.75);
 v.addColorStop(0,'rgba(0,0,0,0)');v.addColorStop(1,'rgba(0,0,0,.85)');X.fillStyle=v;X.fillRect(0,0,W,H);
 X.fillStyle='rgba(255,255,255,.05)';
 for(let i=0;i<140;i++)X.fillRect(Math.random()*W,Math.random()*H,1.2,1.2);
 const bar=H*.09;X.fillStyle='#000';X.fillRect(0,0,W,bar);X.fillRect(0,H-bar,W,bar);
 X.fillStyle=`rgba(0,0,0,${1-clamp(t/2)})`;X.fillRect(0,0,W,H);
}

/* ---------- the story ---------- */
const GOLD='#ffd43b';
const MILES=[
 ['2007','T20 WORLD CUP','नई कप्तानी. पहला विश्व कप.'],
 ['2008','IPL · पहला सीज़न','पीली जर्सी. चेन्नई का दिल. एक रिश्ते की शुरुआत.'],
 ['2010','IPL खिताब #1','Chennai Super Kings बने चैंपियन.'],
 ['2011','ODI WORLD CUP','वानखेड़े की रात. वो छक्का. करोड़ों धड़कनें.'],
 ['2013','CHAMPIONS TROPHY','तीनों ICC व्हाइट-बॉल ट्रॉफी जीतने वाले पहले कप्तान.'],
 ['2018','IPL खिताब #3','दो साल की पाबंदी के बाद वापसी — और सीधे चैंपियन.'],
 ['2023','IPL खिताब #5','पाँचवीं ट्रॉफी. माही का जादू बरकरार.']
];
const STATS=[[5,'IPL TITLES',49],[3,'ICC TROPHIES',51],[7,'THE JERSEY',53]];
const END=104;

function scene(t){
 const sz=clamp(W/28,16,38),cx=W/2,w=clamp(.15+t/76*.65+(t>62?.2:0),0,1);
 bg(t,w);
 const beat=t<20?Math.max(0,Math.sin(t*6.28*(1/(1-t/40))))**8:0;

 // S0 — the silence
 if(t<9){const a=seg(t,0,9,1.5);
  T('07',cx,H*.5,Math.min(W,H)*.45,.07*a+beat*.06,{w:900,c:GOLD,glow:GOLD,gb:60});
  T('17 NOVEMBER 2026',cx,H*.36,sz*.6,seg(t,1,8,1),{ls:10,c:'#e9b824'});
  T('कुछ खिलाड़ी खेल खत्म करते हैं.',cx,H*.5,sz,seg(t,2.5,8,1));
  T('कुछ खेल को बदल देते हैं.',cx,H*.58,sz*1.1,seg(t,4.8,8.5,1),{c:GOLD,w:500,glow:GOLD,gb:20});}

 // S1 — Ranchi
 if(t>=8&&t<21){
  T('7 JULY 1981  ·  RANCHI',cx,H*.34,sz*.6,seg(t,9,20,1.2),{ls:8,c:'#e9b824'});
  T('एक छोटे शहर का लड़का.',cx,H*.47,sz*1.3,seg(t,10.5,20,1.2),{w:500});
  T('बड़े सपने देखने के लिए उसने किसी की इजाज़त नहीं माँगी.',cx,H*.57,sz*.85,seg(t,13.5,20.5,1.2),{c:'#ddd'});}

 // S2 — the legend timeline
 if(t>=20&&t<49){
  MILES.forEach((m,i)=>{const s=21+i*4,a=seg(t,s,s+4.4,.9);if(a<=0)return;
   const k=clamp((t-s)/4.4),yo=(k-.5)*-24;
   T(m[0],cx,H*.38+yo,clamp(W/8,56,150),a,{w:800,c:GOLD,glow:GOLD,gb:40,ls:6});
   T(m[1],cx,H*.53+yo,sz*1.1,a,{w:600,ls:10});
   T(m[2],cx,H*.61+yo,sz*.8,a*.85,{c:'#ccc'});});
  const p=clamp((t-21)/28);X.fillStyle=GOLD;X.fillRect(W*.3,H*.9-3,W*.4*p,2);
  X.fillStyle='rgba(255,255,255,.2)';X.fillRect(W*.3+W*.4*p,H*.9-3,W*.4*(1-p),2);}

 // S3 — numbers
 if(t>=48&&t<63){const a=seg(t,48,63,1.2);
  STATS.forEach(([v,l,s],i)=>{const k=ease(clamp((t-s)/2.2)),x=W*(.2+i*.3);
   T(String(Math.round(v*k)),x,H*.45,clamp(W/9,44,130),a*k,{w:800,c:GOLD,glow:GOLD,gb:40});
   T(l,x,H*.58,sz*.55,a*k,{ls:6,c:'#ddd'});});
  T('आँकड़े कहानी का सिर्फ़ एक हिस्सा हैं.',cx,H*.74,sz*.95,seg(t,57,62.5,1),{w:400,c:'#fff'});}

 // S4 — number 7
 if(t>=61&&t<77){const a=seg(t,62,77,1.4),k=(t-62)/15,S=Math.min(W,H*1.3)*.62*(1+k*.08);
  X.save();X.globalAlpha=a;const gg=X.createLinearGradient(0,H*.25,0,H*.75);
  gg.addColorStop(0,'#fff6b0');gg.addColorStop(.5,GOLD);gg.addColorStop(1,'#b8860b');X.fillStyle=gg;
  X.textAlign='center';X.textBaseline='middle';X.font=`900 ${S}px 'Segoe UI',system-ui,sans-serif`;
  X.shadowColor=GOLD;X.shadowBlur=80;X.fillText('07',cx,H*.47);X.restore();
  const bx=((t-62)/6%1)*(W+400)-200;X.save();X.globalCompositeOperation='lighter';
  const sg=X.createLinearGradient(bx-120,0,bx+120,0);sg.addColorStop(0,'rgba(255,255,255,0)');
  sg.addColorStop(.5,`rgba(255,255,255,${.12*a})`);sg.addColorStop(1,'rgba(255,255,255,0)');
  X.fillStyle=sg;X.fillRect(bx-120,0,240,H);X.restore();
  const rr=(t-62)*W*.5;X.strokeStyle=`rgba(255,212,59,${clamp(1-(t-62)/3)*.7})`;X.lineWidth=3;
  X.beginPath();X.arc(cx,H*.47,rr,0,6.28);X.stroke();
  T('सिर्फ़ एक जर्सी नहीं.',cx,H*.8,sz*1.1,seg(t,66,76,1),{w:500});
  T('एक एहसास.',cx,H*.87,sz*1.3,seg(t,70,76.5,1),{c:GOLD,w:700,glow:GOLD,gb:30});
  if(t<63.5){X.fillStyle=`rgba(255,255,255,${(1-(t-62)/1.5)*.8})`;X.fillRect(0,0,W,H)}}

 // S5 — thank you
 if(t>=75){const f=seg(t,75,END+99,3);
  if(imgOK){const k=clamp((t-75)/30);
   const bs=Math.max(W/IMG.width,H/IMG.height)*1.2;X.save();X.globalAlpha=f*.35;
   if('filter' in X)X.filter='blur(28px)';
   X.drawImage(IMG,cx-IMG.width*bs/2,H/2-IMG.height*bs/2,IMG.width*bs,IMG.height*bs);X.restore();
   const bw=W*.92,bh=H*.56,s=Math.min(bw/IMG.width,bh/IMG.height)*(1+k*.05);
   const iw=IMG.width*s,ih=IMG.height*s,iy=H*.39-ih/2;
   X.save();X.globalAlpha=f;X.shadowColor='#000';X.shadowBlur=40;X.drawImage(IMG,cx-iw/2,iy,iw,ih);X.restore();
   X.save();X.globalAlpha=f;X.strokeStyle='rgba(255,212,59,.35)';X.lineWidth=1;X.strokeRect(cx-iw/2,iy,iw,ih);X.restore();
   const g=X.createLinearGradient(0,H*.64,0,H);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(.5,'rgba(0,0,0,.9)');
   X.fillStyle=g;X.fillRect(0,0,W,H);}
  else T('07',cx,H*.45,Math.min(W,H)*.5,.12*f,{w:900,c:GOLD,glow:GOLD,gb:60});
  T('Thank you, Thala.',cx,H*.70,clamp(W/14,28,86),seg(t,80,END+99,2),{w:700,c:GOLD,glow:GOLD,gb:40});
  T('थैंक यू माही.',cx,H*.78,sz*1.2,seg(t,84,END+99,1.5),{w:500});
  T('आपने सिर्फ़ मैच नहीं जिताए — भरोसा जिताया.',cx,H*.84,sz*.8,seg(t,89,END+99,1.5),{c:'#ddd'});
  T('A TRIBUTE BY  CODING WITH VISHESH',cx,H*.9,sz*.45,seg(t,95,END+99,1.5),{ls:8,c:'#e9b824'});
  if(t>END+2)T('press R to replay',cx,H*.95,12,.5*Math.abs(Math.sin(t)),{ls:4,c:'#aaa'});}
}

/* ---------- director ---------- */
const EV=[
 [8,()=>bright(700,10)],[20,()=>bright(1100,10)],[48,()=>{bright(1600,8);crowd(.04,8)}],
 [62,()=>{thump(1.4);crowd(.45,8);bright(2200,8)}],[71,()=>crowd(.12,5)],
 [76,()=>{[440,554.37,659.25,880,1108.7].forEach((f,i)=>bell(f,i*.5));crowd(.2,4)}],
 [END,()=>{const n=AC.currentTime;master.gain.cancelScheduledValues(n);master.gain.setValueAtTime(master.gain.value,n);master.gain.linearRampToValueAtTime(0,n+8)}]
];
let run=0;
function start(off=0){
 const id=++run,t0=performance.now()-off*1000;const fired=EV.map(e=>e[0]<off?1:0);let nb=.5;
 if(AC){const n=AC.currentTime;master.gain.cancelScheduledValues(n);master.gain.setValueAtTime(muted?0:.9,n);crowd(0,.1);bright(300,.1)}
 (function frame(now){
  if(id!==run)return;const t=(now-t0)/1000;
  EV.forEach((e,i)=>{if(!fired[i]&&t>=e[0]){fired[i]=1;e[1]()}});
  if(AC&&t<20&&t>=nb){thump(.8);setTimeout(()=>thump(.45),230);nb+=1-t/40}
  if(AC&&t>=48&&t<62&&t>=nb){thump(.6);nb=t+.62}
  X.clearRect(0,0,W,H);scene(t);post(t);requestAnimationFrame(frame);
 })(performance.now());
}
$('go').onclick=()=>{$('ov').style.display='none';audioInit();AC.resume();start()};
addEventListener('keydown',e=>{const k=e.key.toLowerCase();
 if(k==='r'&&AC)start();
 if(k==='j'&&AC)start(74);
 if(k==='m'&&AC){muted=!muted;master.gain.value=muted?0:.9}
 if(k==='f')document.fullscreenElement?document.exitFullscreen():document.documentElement.requestFullscreen()});
</script></body></html>'''


def find_photo():
    exts = (".webp", ".jpg", ".jpeg", ".png")
    pref = [p for p in sorted(glob.glob(os.path.join(HERE, "dhoni.*"))) if p.lower().endswith(exts)]
    if pref:
        return pref[0]
    anyimg = [p for p in sorted(glob.glob(os.path.join(HERE, "*"))) if p.lower().endswith(exts)]
    return anyimg[0] if anyimg else None


def build():
    os.makedirs(SITE, exist_ok=True)
    img_js = ""
    photo = find_photo()
    print("  Photo:", os.path.basename(photo) if photo else "NOT FOUND (folder me dhoni.jpg / dhoni.webp rakho)")
    if photo:
        mime = mimetypes.guess_type(photo)[0] or "image/webp"
        with open(photo, "rb") as f:
            b64 = base64.b64encode(f.read()).decode()
        img_js = f'window.DHONI_IMG="data:{mime};base64,{b64}";'
    with open(os.path.join(SITE, "index.html"), "w", encoding="utf-8") as f:
        f.write(HTML.replace("__IMG__", img_js))


class Quiet(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def log_message(self, *a):
        pass


def main():
    build()
    os.chdir(SITE)
    socketserver.TCPServer.allow_reuse_address = True
    try:
        srv = socketserver.ThreadingTCPServer(("127.0.0.1", 8007), Quiet)
    except OSError:
        srv = socketserver.ThreadingTCPServer(("127.0.0.1", 0), Quiet)
    url = f"http://127.0.0.1:{srv.server_address[1]}"
    print(f"\n  07 — THE LAST WHISTLE\n  Open: {url}\n  Ctrl+C to stop\n")
    threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\n  Thank you, Thala.")


if __name__ == "__main__":
    main()
